# Multiclipboard

## Usage
- save : saves contents of clipboard to database
- list : copies list of keywords to clipboard
- [keyword] : loads keyword contents to clipboard