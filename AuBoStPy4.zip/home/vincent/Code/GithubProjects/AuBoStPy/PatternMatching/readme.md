# Basic Pattern Matching Program
## Overview
A basic python script, which:
- takes the text off clipboard
- processes it for available phone numbers and emails
- copies the line seperated results to clipboard

## Requirements
- python 3
- pyperclip module 
- re module
> Ensure the required modules are existing and working on chosen 
system: Linux systems require the install of extra packages for
pyperclip to work.

## Learnings
- To use the re and pyperclip modules
- Creating required regexes for optimal matching
