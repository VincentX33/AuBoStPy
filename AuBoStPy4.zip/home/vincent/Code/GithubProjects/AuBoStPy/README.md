# AuBoStPy
Code for the Automate The Boring Stuff With Python
